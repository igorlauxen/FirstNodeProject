# Testing on Python

## How to setup PyCharm

1. Install [python for windows](https://docs.python.org/3/using/windows.html)
2. [Install pycharm IDE](https://www.jetbrains.com/pycharm/download/)
3. Installing using [pip and virtual env](https://packaging.python.org/guides/installing-using-pip-and-virtualenv/)

## How to create a unit test class

1. Create under a folder called `test` to make things well organized
2. Import the class which you want to test
3. Create the `setUp` function to start variables
4. All tests must start with the word `test`



