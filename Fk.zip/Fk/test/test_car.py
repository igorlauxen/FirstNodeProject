import unittest
from car import Car

from exceptions.PieceNotFoundException import PieceNotFoundException

class CarTest(unittest.TestCase):

    def setUp(self):
        self.c1 = Car("Car1", "Blue", "Type1")
        self.c2 = Car("Car2", "Red", "Type1")

    def test_carShouldWalk(self):
        self.c1.run(50)
        self.c1.run(20)
        self.assertTrue(self.c1.getKM() == 70, "failed to walk")

    def test_carShouldStartWithZero(self):
        self.assertTrue(self.c2.getKM() == 0, "fail to start")

    def test_carShouldResetKM(self):
        self.c1.resetKM()
        self.assertTrue(self.c1.getKM() == 0, "fail to reset")

    def test_BrokenParts(self):
        self.c1.addBrokenParts('Vidro traseiro')
        self.c1.addBrokenParts('motor')
        self.c1.addBrokenParts('Carburador')
        self.assertEqual(len(self.c1.getBrokenParts()), 3, "some parts have been lost!")
        self.c1.fixBrokenPart('Vidro traseiro')
        self.assertEqual(len(self.c1.getBrokenParts()), 2, "Part was removed!")

    def test_fixValidPiece(self):
        partName = 'LP'
        self.c1.addBrokenParts(partName)
        removedPiece = self.c1.fixBrokenPart(partName)
        self.assertIsNotNone(removedPiece, "Piece was not found!")
        self.assertEqual(removedPiece, partName)

    def test_fixNonExistingBrokenPar(self):
        self.c1.addBrokenParts('Vidro traseiro')
        try:
            self.c1.fixBrokenPart('hu3')
        except PieceNotFoundException:
            pass
        except Exception as e:
            self.fail('Unexpected exception raised:', e)
        else:
            self.fail('ExpectedException not raised')

    def test_RemoveBrokenPartsWithEmptyList(self):
        self.assertEqual(self.c2.fixBrokenPart('motor'), 'No parts have been broken yet')


if __name__ == "__main__":
    unittest.main()
