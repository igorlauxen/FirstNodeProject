from car import Car

c1 = Car("Car1", "Blue", "Type1")
c2 = Car("Car2", "Red", "Type1")

c1.run(20);
c1.run(30);
c1.showKM();
c2.showKM();