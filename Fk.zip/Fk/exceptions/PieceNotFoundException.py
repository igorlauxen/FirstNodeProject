class PieceNotFoundException(Exception):
    def __init__(self, *args):
        Exception.__init__(self, "No piece was found with the name: " + args[0])