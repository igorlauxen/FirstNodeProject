from exceptions.PieceNotFoundException import PieceNotFoundException

class Car:
    def __init__(self, name, color, wheels):
        self.wheels = wheels
        self.name = name
        self.color = color
        self.km = 0
        self.brokenParts = []

    def run(self, km):
        self.km += km

    def showKM(self):
        print("I walked the km: ", self.km)

    def resetKM(self):
        self.km=0

    def getKM(self):
        return self.km

    def addBrokenParts(self, brokenPartName):
        self.brokenParts.append(brokenPartName)

    def getBrokenParts(self):
        return self.brokenParts;

    def howManyBrokenPartsMyCarHas(self):
        return len(self.brokenParts);

    def fixBrokenPart(self, brokenPartName):
        if len(self.brokenParts) < 1:
            return 'No parts have been broken yet'
        try:
            self.brokenParts.remove(brokenPartName)
        except ValueError:
            raise PieceNotFoundException(brokenPartName)
        return brokenPartName
